import { initializeApp } from "https://www.gstatic.com/firebasejs/11.9.1/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/11.9.1/firebase-firestore.js";

// ✅ Firebase Setup
const firebaseConfig = {
  apiKey: "AIzaSyD9tMYYbrrIeg8IzJr6HsmSLTQkrpPS6O0",
  authDomain: "userlogindb-76260.firebaseapp.com",
  databaseURL: "https://userlogindb-76260-default-rtdb.firebaseio.com",
  projectId: "userlogindb-76260",
  storageBucket: "userlogindb-76260.firebasestorage.app",
  messagingSenderId: "1010679264774",
  appId: "1:1010679264774:web:780f788497e943015b7587"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const bookingsRef = collection(db, "bookings");

const bookedDates = {};
const selectedItems = [];

const calendar = document.getElementById("calendar");
const itemSelect = document.getElementById("itemSelect");
const itemsDisplay = document.getElementById("itemsDisplay");
const selectedItemsList = document.getElementById("selectedItemsList");
const message = document.getElementById("message");

const items = {
  "Camera": { qty: 3, img: "https://cdn-icons-png.flaticon.com/512/2920/2920383.png" },
  "Tripod": { qty: 2, img: "https://cdn-icons-png.flaticon.com/512/4082/4082122.png" },
  "Mic": { qty: 3, img: "https://cdn-icons-png.flaticon.com/512/727/727240.png" },
  "Lights": { qty: 2, img: "https://cdn-icons-png.flaticon.com/512/2965/2965567.png" }
};

const today = new Date();
let year = today.getFullYear();
let month = today.getMonth();

function pad(n) {
  return n.toString().padStart(2, '0');
}

function getDaysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}

function renderCalendar(year, month, highlightDate = "") {
  calendar.innerHTML = `
    <div class="day-name">Sun</div>
    <div class="day-name">Mon</div>
    <div class="day-name">Tue</div>
    <div class="day-name">Wed</div>
    <div class="day-name">Thu</div>
    <div class="day-name">Fri</div>
    <div class="day-name">Sat</div>
  `;

  const daysInMonth = getDaysInMonth(year, month);
  const firstDayOfWeek = new Date(year, month, 1).getDay();

  for (let i = 0; i < firstDayOfWeek; i++) {
    calendar.appendChild(document.createElement("div"));
  }

  for (let i = 1; i <= daysInMonth; i++) {
    const dateStr = `${year}-${pad(month + 1)}-${pad(i)}`;
    const div = document.createElement("div");
    div.className = "day";
    div.textContent = i;

    if (bookedDates[dateStr]) {
      div.classList.add("booked");
    }

    if (dateStr === highlightDate) {
      div.style.border = "2px solid green";
    }

    calendar.appendChild(div);
  }
}

function renderItems() {
  itemsDisplay.innerHTML = '';
  itemSelect.innerHTML = '';
  for (const [name, data] of Object.entries(items)) {
    const div = document.createElement("div");
    div.className = "item";
    div.innerHTML = `<img src="${data.img}" /><br>${name}<br>x${data.qty}`;
    itemsDisplay.appendChild(div);

    const option = document.createElement("option");
    option.value = name;
    option.textContent = name;
    itemSelect.appendChild(option);
  }
}

function updateSelectedItemsList() {
  selectedItemsList.innerHTML = '';
  selectedItems.forEach(({ name, quantity }) => {
    const li = document.createElement("li");
    li.textContent = `${name} x${quantity}`;
    selectedItemsList.appendChild(li);
  });
}

document.getElementById("addItemBtn").addEventListener("click", () => {
  const item = itemSelect.value;
  const qty = parseInt(document.getElementById("quantityInput").value);
  if (!item || isNaN(qty) || qty <= 0) {
    message.textContent = "❌ Please select a valid item and quantity.";
    message.style.color = "red";
    return;
  }

  const existing = selectedItems.find(i => i.name === item);
  const alreadyQty = existing ? existing.quantity : 0;
  if (items[item].qty < qty + alreadyQty) {
    message.textContent = `❌ Not enough ${item}s available.`;
    message.style.color = "red";
    return;
  }

  if (existing) {
    existing.quantity += qty;
  } else {
    selectedItems.push({ name: item, quantity: qty });
  }

  updateSelectedItemsList();
  message.textContent = "";
});

document.getElementById("submitBtn").addEventListener("click", async () => {
  const startInput = document.getElementById("startDate").value;
  const endInput = document.getElementById("endDate").value;

  if (!startInput || !endInput) {
    message.textContent = "❌ Please enter both start and end dates.";
    message.style.color = "red";
    return;
  }

  const start = new Date(startInput);
  const end = new Date(endInput);
  if (start > end) {
    message.textContent = "❌ Start date must be before end date.";
    message.style.color = "red";
    return;
  }

  if (selectedItems.length === 0) {
    message.textContent = "❌ No items selected.";
    message.style.color = "red";
    return;
  }

  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const key = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    if (bookedDates[key]) {
      message.textContent = `❌ ${key} is already booked.`;
      message.style.color = "red";
      return;
    }
  }

  // ✅ Pass to confirmation page
  const formData = {
    startDate: startInput,
    endDate: endInput,
    items: selectedItems
  };

  localStorage.setItem("bookingFormData", JSON.stringify(formData));
  window.location.href = "confirmation-page.html";
});

document.getElementById("checkDate").addEventListener("change", () => {
  const input = document.getElementById("checkDate").value;
  const result = document.getElementById("checkResult");

  if (!input) {
    result.textContent = "❌ Please select a date.";
    result.style.color = "red";
    return;
  }

  const booked = bookedDates[input];
  if (booked) {
    result.textContent = `❌ ${input} is already booked.`;
    result.style.color = "red";
  } else {
    result.textContent = `✅ ${input} is available.`;
    result.style.color = "green";
  }

  const d = new Date(input);
  year = d.getFullYear();
  month = d.getMonth();
  renderCalendar(year, month, input);
});

async function loadBookings() {
  const snapshot = await getDocs(bookingsRef);
  snapshot.forEach(doc => {
    const { startDate, endDate } = doc.data();
    const start = new Date(startDate);
    const end = new Date(endDate);
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const key = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
      bookedDates[key] = true;
    }
  });

  renderCalendar(year, month);
}

renderItems();
await loadBookings();